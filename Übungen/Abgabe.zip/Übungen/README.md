Alle Dateien sind mit folgenden Befehl aufrufbar:

Thema 1
java -cp Rouven_Lacour_Uebungen.jar uebung.thema1.Main

Thema 2
java -cp Rouven_Lacour_Uebungen.jar uebung.thema2.Main

Thema 3
java -cp Rouven_Lacour_Uebungen.jar uebung.thema3.Main

Thema 4
java -cp Rouven_Lacour_Uebungen.jar uebung.thema4.Main

Thema 5
java -cp Rouven_Lacour_Uebungen.jar uebung.thema5.Main